/*
Programmer: Nandi Patel 

Final Project: Making a Trouble Ticket Management System

 */

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager; 


@SuppressWarnings("serial")
public class Tickets extends JFrame implements ActionListener {

	// class level member objects
	Dao dao = new Dao(); // for CRUD operations
	Boolean chkIfAdmin = null;

	// Main menu object items
	private JMenu mnuFile = new JMenu("File");
	private JMenu mnuAdmin = new JMenu("Admin");
	private JMenu mnuTickets = new JMenu("Tickets");

	// Sub menu item objects for all Main menu item objects
	JMenuItem mnuItemExit;
	JMenuItem mnuItemUpdate;
	JMenuItem mnuItemDelete;
	JMenuItem mnuItemOpenTicket;
	JMenuItem mnuItemViewTicket;
	JMenuItem mnuItemCloseTicket;

	public Tickets(Boolean isAdmin) {

		chkIfAdmin = isAdmin;
		createMenu();
		prepareGUI();

	}

	private void createMenu() {

		/* Initialize sub menu items **************************************/

		// initialize sub menu item for File main menu
		mnuItemExit = new JMenuItem("Exit");
		// add to File main menu item
		mnuFile.add(mnuItemExit);

		// initialize first sub menu items for Admin main menu
		mnuItemUpdate = new JMenuItem("Update Ticket");
		// add to Admin main menu item
		mnuAdmin.add(mnuItemUpdate);

		// initialize second sub menu items for Admin main menu
		mnuItemDelete = new JMenuItem("Delete Ticket");
		// add to Admin main menu item
		mnuAdmin.add(mnuItemDelete);

		// initialize first sub menu item for Tickets main menu
		mnuItemOpenTicket = new JMenuItem("Open Ticket");
		// add to Ticket & admin Main menu item
		mnuTickets.add(mnuItemOpenTicket);
		mnuAdmin.add(mnuItemOpenTicket);

		// initialize second sub menu item for Tickets main menu
		mnuItemViewTicket = new JMenuItem("View Ticket");
		// add to Ticket & admin Main menu item
		mnuTickets.add(mnuItemViewTicket);
		mnuAdmin.add(mnuItemViewTicket);

		// initialize third sub menu item for Tickets main menu
		mnuItemCloseTicket = new JMenuItem("Close Ticket");
		// add to Ticket & admin  Main menu item
		mnuTickets.add(mnuItemCloseTicket);
		mnuAdmin.add(mnuItemCloseTicket);

		/* Add action listeners for each desired menu item *************/
		mnuItemExit.addActionListener(this);
		mnuItemUpdate.addActionListener(this);
		mnuItemDelete.addActionListener(this);
		mnuItemOpenTicket.addActionListener(this);
		mnuItemViewTicket.addActionListener(this);
		mnuItemCloseTicket.addActionListener(this);

	}

	private void prepareGUI() {

		// create JMenu bar
		JMenuBar bar = new JMenuBar();
		bar.add(mnuFile); // add main menu items in order, to JMenuBar
		bar.add(mnuAdmin);
		bar.add(mnuTickets);
		// add menu bar components to frame
		setJMenuBar(bar);

		addWindowListener(new WindowAdapter() {
			// define a window close operation
			public void windowClosing(WindowEvent wE) {
				System.exit(0);
			}
		});
		// set frame options
		setSize(400, 400);
		UIManager.put("MenuBar.background", Color.ORANGE);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// implement actions for sub menu items
		if (e.getSource() == mnuItemExit) {
			System.exit(0);

			//opening ticket
		} else if (e.getSource() == mnuItemOpenTicket) {

			// get ticket information
			String ticketName = JOptionPane.showInputDialog(null, "Enter your name");
			String ticketDesc = JOptionPane.showInputDialog(null, "Enter a ticket description");

			// insert ticket information to database
			int id = dao.insertRec(ticketName, ticketDesc);

			// display results if successful or not to console / dialog box
			if (id != 0) {
				System.out.println("Ticket ID : " + id + " created successfully!!!");
				JOptionPane.showMessageDialog(null, "Ticket id: " + id + " created");
			} else
				System.out.println("Ticket cannot be created!!!");
		}

		//viewing ticket 
		else if (e.getSource() == mnuItemViewTicket) {
			// retrieve all tickets details for viewing in JTable
			try {
				// Use JTable built in functionality to build a table model and
				// display the table model off your result set!!!
				JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRec()));
				jt.setBounds(30, 40, 200, 400);
				JScrollPane sp = new JScrollPane(jt);
				add(sp);
				setVisible(true); // refreshes or repaints frame on screen

			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		//closing ticket
		else if (e.getSource() == mnuItemCloseTicket) {
			// get ticket number
			String ticket_id = JOptionPane.showInputDialog(null, "Enter in ticket number:");
			//closing ticket information to database
			String id = dao.closeRec(ticket_id);

			int response = JOptionPane.showConfirmDialog(null, "Do you want to close ticket # " + ticket_id + "?", "Confirm" ,JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE);
			if (response == JOptionPane.NO_OPTION) {
				System.out.println("Ticket not closed!");
			} else if (response == JOptionPane.YES_OPTION) {
				dao.closeRec(id);
				System.out.println("Ticket # "+ticket_id+" Closed!");
			} else if (response == JOptionPane.CLOSED_OPTION) {
				System.out.println("**Request cancelled**");
			}

		}

		//updating ticket
		else if (e.getSource() == mnuItemUpdate) {
			// get ticket information
			String ticket_id = JOptionPane.showInputDialog(null, "Enter in ticket number:");
			String ticket_desc = JOptionPane.showInputDialog(null, "Enter in ticket description:");

			int response = JOptionPane.showConfirmDialog(null, "Do you want to update ticket # " + ticket_id + "?", "Confirm" ,JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE);
			if (response == JOptionPane.NO_OPTION) {
				System.out.println("Ticket not updated");
			} else if (response == JOptionPane.YES_OPTION) {
				dao.updateRec(ticket_desc, ticket_id);
				System.out.println("Ticket # "+ticket_id+" Updated!");
			} else if (response == JOptionPane.CLOSED_OPTION) {
				System.out.println("**Request cancelled**");
			}

		}

		//deleting ticket
		else if (e.getSource() == mnuItemDelete) {	

			// get ticket information
			String ticket_id = JOptionPane.showInputDialog(null, "Enter in ticket number:");

			// delete ticket information to database
			String id = dao.deleteRec(ticket_id);

			int response = JOptionPane.showConfirmDialog(null, "Do you want to delete ticket # " + ticket_id + "?", "Confirm" ,JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE);
			if (response == JOptionPane.NO_OPTION) {
				System.out.println("Ticket not deleted");
			} else if (response == JOptionPane.YES_OPTION) {
				dao.deleteRec(id);
				System.out.println("Ticket # "+ticket_id+" Deleted!");
			} else if (response == JOptionPane.CLOSED_OPTION) {
				System.out.println("**Request cancelled**");
			}

		}
	}
}

