/*
Programmer: Nandi Patel 

Final Project: Making a Trouble Ticket Management System

 */

import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.time.LocalDate;


//This file will allow for database connectivity and CRUD like operations.
public class Dao {
	//Declare DB objects 
	static Connection conn = null;
	Statement stment = null;

	// constructor
	public Dao() { }  //create db object instance

	//connecting to the database 
	public Connection getConnection(){
		try {
			conn = DriverManager.getConnection("jdbc:mysql://www.papademas.net:3307/tickets?autoReconnect=true&useSSL=false"
					+ "&user=fp411&password=411");
		} catch (SQLException except) {
			except.printStackTrace();
		}
		return conn;
	}

	// Creating tables 
	public void createTable() {
		// //sql statement create tables 
		final String createTicketsTable = "CREATE TABLE npatetrial_tickets(ticket_id INT AUTO_INCREMENT PRIMARY KEY, ticket_issuer VARCHAR(30), ticket_desc VARCHAR(200)" + 
				", open_date DATE NULL, status VARCHAR(20))";
		final String createUsersTable = "CREATE TABLE npatetrial_users(user_id INT AUTO_INCREMENT PRIMARY KEY, user_name VARCHAR(30), user_pass VARCHAR(30), admin int)";

		try {
			//will execute the queries, above, to create the tables
			stment = getConnection().createStatement();

			stment.executeUpdate(createTicketsTable); //creating ticket table
			stment.executeUpdate(createUsersTable); //creating users table
			System.out.println("Created tables in the given database..."); 

			// end create table & close connection/statement object
			stment.close();
			conn.close();
		} catch (SQLException exception) {
			// exception message
			System.out.println(exception.getMessage());
		}
		//adding users to user table
		addUser();
	}

	// adding users 
	public void addUser() {
		// adding users from users.csv file to user table

		String sql; // variable for SQL Query inserts
		Statement stment; // variable for SQL Query inserts

		BufferedReader bread;
		List<List<String>> array = new ArrayList<>(); // list to hold (rows & columns)

		// reading the data from file
		try {
			bread = new BufferedReader(new FileReader(new File("./UserList.csv")));

			String line;
			while ((line = bread.readLine()) != null) {
				array.add(Arrays.asList(line.split(",")));
			}
		} catch (Exception except) {
			System.out.println("Problem: Loading File Error!");
		}

		//inserting the read data into table
		try {
			// Setting up the connection with the database
			stment = getConnection().createStatement();

			// created a loop to grab each array index containing a list of values
			// and inserting that data into the Users table
			for (List<String> rowData : array) {
				sql = "insert into npatetrial_users(user_name,user_pass,admin) " + "values('" + rowData.get(0) + "'," + " '"
						+ rowData.get(1) + "','" + rowData.get(2) + "');";
				stment.executeUpdate(sql);
			}
			System.out.println("Inserted into the given database...");

			// closing statement object
			stment.close();

		} catch (Exception except) {
			System.out.println(except.getMessage());
		}
	}

	// inserting records  
	public int insertRec (String t_name, String t_desc) {
		int ID =0;
		//current date
		LocalDate date = LocalDate.now();  // Create a date object
		try {
			stment = getConnection().createStatement();
			stment.executeUpdate("Insert into npatetrial_tickets" + "(ticket_issuer, ticket_desc, open_date, status) values(" + " '"
					+ t_name + "','" + t_desc + "','" + date + "', 'OPEN')", Statement.RETURN_GENERATED_KEYS); //sql statement to execute

			// retrieving the ticket id number newly auto generated upon record insertion
			ResultSet resultSet = null;
			resultSet = stment.getGeneratedKeys();
			if (resultSet.next()) {
				// retrieve first field in table
				ID = resultSet.getInt(1);
			}
		} catch (SQLException except) {
			except.printStackTrace();
		}
		return ID;
	}

	// selecting results 
	public ResultSet readRec() {

		ResultSet results = null;
		try {
			stment = conn.createStatement();
			results = stment.executeQuery("SELECT * FROM npatetrial_tickets");
			//connect.close();
		} catch (SQLException except1) {
			except1.printStackTrace();
		}
		return results;
	}

	// updating records 
	public String updateRec(String ticket_id, String ticket_desc) {
		System.out.println("Creating update statement...");
		try {
			stment = getConnection().createStatement();
			stment.executeUpdate("UPDATE npatetrial_tickets SET ticket_desc = '" + ticket_desc + "' WHERE ticket_id =" + ticket_id);

		} catch (SQLException except) {
			except.printStackTrace();
		}
		return null;
	}

	// deleting records 
	public String deleteRec(String ticket_id) {
		System.out.println("Creating statement...");
		try {
			stment = conn.createStatement();
			stment.executeUpdate("DELETE FROM npatetrial_tickets WHERE ticket_id =" + ticket_id);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	//closing records
	public String closeRec(String ticket_id) {
		// closing records 
		System.out.println("Creating closing statement...");
		try {
			stment = getConnection().createStatement();
			stment.executeUpdate("UPDATE npatetrial_tickets SET status = 'CLOSED' WHERE ticket_id =" + ticket_id);

		} catch (SQLException except) {
			except.printStackTrace();
		}
		return null;
	}
}




